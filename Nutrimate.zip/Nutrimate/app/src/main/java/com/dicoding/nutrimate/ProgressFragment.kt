package com.dicoding.nutrimate


import androidx.fragment.app.Fragment


class ProgressFragment : Fragment(R.layout.fragment_progress) {
    // Implementasi fragment untuk Home
}
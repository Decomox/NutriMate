package com.dicoding.nutrimate

import androidx.fragment.app.Fragment


class HomeFragment : Fragment(R.layout.fragment_home) {
    // Implementasi fragment untuk Home
}
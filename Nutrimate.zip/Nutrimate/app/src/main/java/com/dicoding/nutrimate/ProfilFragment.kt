package com.dicoding.nutrimate

import androidx.fragment.app.Fragment

class ProfilFragment : Fragment(R.layout.fragment_profil) {
    // Implementasi fragment untuk Home
}